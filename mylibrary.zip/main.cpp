#include <iostream>
#include "mathlib.h"
using namespace std;

int main() {
    cout << "Add: " << MathLib::add(10, 5) << endl;
    cout << "Subtract: " << MathLib::subtract(10, 5) << endl;
    cout << "Multiply: " << MathLib::multiply(10, 5) << endl;
    cout << "Divide: " << MathLib::divide(10, 5) << endl;
    cout << "Factorial: " << MathLib::factorial(5) << endl;
    cout << "GCD: " << MathLib::gcd(10, 5) << endl;
    cout << "LCM: " << MathLib::lcm(10, 5) << endl;
    return 0;
}
