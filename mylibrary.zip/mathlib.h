#ifndef MATHLIB_H
#define MATHLIB_H

namespace MathLib {
    int add(int a, int b);
    int subtract(int a, int b);
    int multiply(int a, int b);
    double divide(int a, int b);
    long long factorial(int n);
    int gcd(int a, int b);
    int lcm(int a, int b);
}

#endif
