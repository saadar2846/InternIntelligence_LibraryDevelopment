#include "mathlib.h"

namespace MathLib {
    int add(int a, int b) { return a + b; }
    int subtract(int a, int b) { return a - b; }
    int multiply(int a, int b) { return a * b; }
    double divide(int a, int b) { return (b != 0) ? (double)a / b : 0; }
    long long factorial(int n) {
        if (n <= 1) return 1;
        return n * factorial(n - 1);
    }
    int gcd(int a, int b) {
        while (b != 0) {
            int t = b;
            b = a % b;
            a = t;
        }
        return a;
    }
    int lcm(int a, int b) {
        return (a * b) / gcd(a, b);
    }
}
